
import Dashboard from "@material-ui/icons/Dashboard";
import Person from "@material-ui/icons/Person";
import LibraryBooks from "@material-ui/icons/LibraryBooks";

import DashboardPage from "./views/Dashboard/Dashboard.js";
import UserProfile from "./views/UserProfile/UserProfile.js";
import TableList from "./views/TableList/TableList.js";
import Typography from "./views/Typography/Typography.js";


const dashboardRoutes = [
  {
    path: "/fav",
    name: "Home",  
    icon: Dashboard,
    component: DashboardPage,
    layout: "/home"
  },
  {
    path: "/functions",
    name: "Functions",
    icon: Person,
    component: UserProfile,
    layout: "/home"
  },
  {
    path: "/locations",
    name: "Locations",
    icon: "content_paste",
    component: TableList,
    layout: "/home"
  },
  {
    path: "/settings",
    name: "Settings",
    icon: LibraryBooks,
    component: Typography,
    layout: "/home"
  }
];

export default dashboardRoutes;
