import React from "react";



export default function TypographyPage() {
 
  return (
    <h1>Typography Page</h1>
    );
}
