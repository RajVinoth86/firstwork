import React from "react";




export default function TableList() {
  
  return (
    <h1>Tables</h1>
    );
}
