const express = require("express");
const router = express.Router();
const convert = require('xml-js');
const xmlfile = require('fs');

router.get('/appConfig', (req, res) => {
    var file = xmlfile.readFileSync('project.xml', 'utf8');
    // var xmlTojson = convert.xml2json(file, {compact: false});
    var compactJson = convert.xml2json(file, {compact: true});
    res.send(
      {
        sucess: true,
        data: JSON.parse(compactJson),
        compactJson: JSON.parse(compactJson),
      } 
    );
});

router.post('/updateAppConfig', (req, res) => {
    var jsontoxml= convert.js2xml(req.body, { compact: true, spaces: 2, attributeValueFn: function(attributeValue) {
        return attributeValue.replace(/&quot;/g, '"')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
      }});;
    xmlfile.writeFile("project.xml", jsontoxml, function(err, data) {
      if (err) console.log(err);
      res.send(
        {
          sucess: true,
          message: "successfully updated"
        } 
      );
    });
});

module.exports = router;



