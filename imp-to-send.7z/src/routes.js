
// @material-ui/icons
import Dashboard from "@material-ui/icons/Dashboard";
import Person from "@material-ui/icons/Person";
import LibraryBooks from "@material-ui/icons/LibraryBooks";

// core components/views for Admin layout
import Favorite from "views/Favorites/Favorite.js";
import Location from "views/Locations/Location.js";
import Function from "views/Functions/Function.js";
import Setting from "views/Settings/Setting.js";

const dashboardRoutes = [
  {
    path: "/favorite",
    name: "Home",
    // rtlName: "لوحة القيادة",
    icon: Dashboard,
    component: Favorite,
    layout: "/home"
  },
  {
    path: "/locations",
    name: "Locations",
    // rtlName: "ملف تعريفي للمستخدم",
    icon: Person,
    component: Location,
    layout: "/home"
  },
  {
    path: "/functions",
    name: "Functions",
    // rtlName: "قائمة الجدول",
    icon: "content_paste",
    component: Function,
    layout: "/home"
  },
  {
    path: "/setting",
    name: "Settings",
    // rtlName: "طباعة",
    icon: LibraryBooks,
    component: Setting,
    layout: "/home"
  }

];

export default dashboardRoutes;
