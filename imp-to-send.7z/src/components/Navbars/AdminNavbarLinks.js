import React from "react";

import { makeStyles } from "@material-ui/core/styles";

import styles from "assets/js/all-styles/components/headerLinksStyle.js";

const useStyles = makeStyles(styles);

export default function AdminNavbarLinks() {
  const classes = useStyles();

 

  return (
    <div>          
      <div className={classes.manager}>       
       <h1>Heander Content</h1>
      </div>
    </div>
  );
}
