import React from "react";


export default function Setting() {
  
  return (<h1>Settings Page</h1>
  )
}
