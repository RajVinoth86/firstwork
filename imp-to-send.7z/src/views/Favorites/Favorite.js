import React from "react";


export default function Favorite() {
  
  return (<h1>Home Page</h1>
  )
}
