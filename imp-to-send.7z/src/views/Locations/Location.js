import React from "react";


export default function Location() {
  
  return (<h1>Locations Page</h1>
  )
}
