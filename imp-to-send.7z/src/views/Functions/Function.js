import React from "react";


export default function Function() {
  
  return (<h1>Functions Page</h1>
  )
}
